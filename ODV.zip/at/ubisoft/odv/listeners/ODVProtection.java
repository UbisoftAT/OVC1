package at.ubisoft.odv.listeners;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;

import at.ubisoft.odv.gamemanager.GameState;
import at.ubisoft.odv.gamemanager.GameType;
import at.ubisoft.odv.main.ODVCore;

public class ODVProtection implements Listener {

	@EventHandler
	public void onCraft(CraftItemEvent e) {
		if (new GameType().isEnabled("bowless")) {
			if (e.getRecipe().getResult().getType() == Material.BOW) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onCraft2(CraftItemEvent e) {
		if (new GameType().isEnabled("rodless")) {
			if (e.getRecipe().getResult().getType() == Material.FISHING_ROD) {
				e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onTame(EntityTameEvent e) {
		if (new GameType().isEnabled("horseless")) {
		if (e.getEntityType() == EntityType.HORSE) {
			e.setCancelled(true);
			}
		}
	}
	
	@EventHandler
	public void onBreak2(BlockBreakEvent e) {
		if (new GameType().isEnabled("vanillap")) {
			if (e.getBlock().getType() == Material.LEAVES) {
				if (Math.random() < 0.25) {
					e.getBlock().getDrops().add(getItem(Material.APPLE));
				}
			} else if (e.getBlock().getType() == Material.GRAVEL) {
				if (Math.random() < 0.25) {
					e.getBlock().getDrops().add(getItem(Material.FLINT));
				}
			}
		} else if (new GameType().isEnabled("diamondless")) {
			if (e.getBlock().getType() == Material.DIAMOND_ORE) {
				e.setCancelled(true);
			}
		}

	}

	@SuppressWarnings("deprecation")
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		Player p = e.getPlayer();
		e.setJoinMessage("");
		
		p.performCommand("warp Lobby");
		p.setHealth(20);
		p.setFoodLevel(20);
		p.setGameMode(GameMode.SURVIVAL);
		p.sendTitle("�eOneDayVaro", "�apr�sentiert euch UbisoftAT");
		p.getInventory().clear();
		p.getInventory().setHelmet(null);
		p.getInventory().setChestplate(null);
		p.getInventory().setLeggings(null);
		p.getInventory().setBoots(null);

	}
	
	@EventHandler
	public void onFood(FoodLevelChangeEvent e) {
		if (ODVCore.gs == GameState.LOBBY || ODVCore.gs == GameState.PRE_GAME) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		e.setQuitMessage("");
	}
	
	@EventHandler
	public void onDeath2(EntityDeathEvent e) {
	if (new GameType().isEnabled("cutclean")) {
			if (e.getEntityType() == EntityType.COW) {
				e.getDrops().add(getItem(Material.LEATHER));
			}
		}
	}

	@EventHandler
	public void onDamage2(EntityDamageEvent e) {
		if (ODVCore.gs == GameState.LOBBY || ODVCore.gs == GameState.PRE_GAME) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onDamage(EntityDamageByEntityEvent e) {
		Player p = (Player) e.getEntity();
		if (e.getEntity() instanceof Player) {
		if (ODVCore.gs == GameState.LOBBY || ODVCore.gs == GameState.PRE_GAME) {
			e.setCancelled(true);
		} else {
			
			if (new GameType().isEnabled("fireless")) {
				if (e.getCause() == DamageCause.FIRE || e.getCause() == DamageCause.FIRE_TICK && p.getWorld().getName().equalsIgnoreCase("odv")) {
					e.setCancelled(true);
				}
			}
			
			for (Player all : Bukkit.getOnlinePlayers()) {
				if (all.hasPermission("ubi.admin")) {
					if (e.getCause() == DamageCause.ENTITY_ATTACK) {
						all.sendMessage("�eItsLoru �8| �e" + p.getName() + " �awird von �c" + e.getDamager().getName() + " �aangegriffen.");
					}
				}
			}
		}
		}
	}

	@EventHandler
	public void onChange(WeatherChangeEvent e) {
		if (ODVCore.gs == GameState.LOBBY) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onDeath(PlayerDeathEvent e) {
		Player p = (Player) e.getEntity();
		if (ODVCore.gs == GameState.INGAME) {
			
			if (new GameType().isEnabled("diamondless")) {
				e.getDrops().add(getItem(Material.DIAMOND));
			}

			Bukkit.broadcastMessage("�eItsLoru �8| �e" + p.getName() + " �aist gestorben.");
		}
	}

	@EventHandler
	public void onPlace(BlockPlaceEvent e) {
		if (ODVCore.gs == GameState.LOBBY) {
			e.setCancelled(true);
		}
	}
	
	@EventHandler
	public void onBreak(BlockBreakEvent e) {
		Player p = e.getPlayer();
		if (ODVCore.gs == GameState.LOBBY) {
			e.setCancelled(true);
		} else {
		if (e.getBlock().getDrops().contains(getItem(Material.IRON_ORE))) {
			e.setCancelled(true);
			e.getBlock().setType(Material.AIR);
			p.getInventory().addItem(getItem(Material.IRON_INGOT));
		} else if (e.getBlock().getDrops().contains(getItem(Material.GOLD_ORE))) {
			e.setCancelled(true);
			e.getBlock().setType(Material.AIR);
			p.getInventory().addItem(getItem(Material.GOLD_INGOT));
		}
	}
}

	public ItemStack getItem(Material mat) {
		return new ItemStack(mat);
	}

}

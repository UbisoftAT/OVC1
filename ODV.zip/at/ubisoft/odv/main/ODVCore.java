package at.ubisoft.odv.main;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.plugin.java.JavaPlugin;

import at.ubisoft.odv.commands.*;
import at.ubisoft.odv.gamemanager.GameState;
import at.ubisoft.odv.listeners.ODVProtection;

public class ODVCore extends JavaPlugin {
	
	public static GameState gs;
	public static ODVCore instance;
	
	public void onEnable() {
		
		instance = this;
		gs = GameState.LOBBY;
				
		Bukkit.getPluginManager().registerEvents(new ODVProtection(), this);
		
		Bukkit.setDefaultGameMode(GameMode.SURVIVAL);
		
		getCommand("gamemode").setExecutor(new GameModes());
		getCommand("teams").setExecutor(new Teams());
		getCommand("set").setExecutor(new Set());
		getCommand("warp").setExecutor(new Warp());

	}
	
	public void onDisable() {}

}

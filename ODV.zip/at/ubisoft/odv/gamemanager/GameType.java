package at.ubisoft.odv.gamemanager;

public class GameType {
	
	boolean bowless;
	boolean cutclean;
	boolean diamondless;
	boolean horseless;
	boolean rodless;
	boolean timebomb;
	boolean vanillap;
	boolean fireless;
	boolean backpack;
	boolean ironless;
	boolean limitations;
	boolean splitedlive;

	public GameType() {}
	
	public void enable(String type) {
		if (type.equalsIgnoreCase("bowless")) {
			bowless = true;
		} else if (type.equalsIgnoreCase("cutclean")) {
			cutclean = true;
		} else if (type.equalsIgnoreCase("diamondless")) {
			diamondless = true;
		} else if (type.equalsIgnoreCase("horseless")) {
			horseless = true;
		} else if (type.equalsIgnoreCase("rodless")) {
			rodless = true;
		} else if (type.equalsIgnoreCase("timebomb")) {
			timebomb = true;
		} else if (type.equalsIgnoreCase("vanillap")) {
			vanillap = true;
		} else if (type.equalsIgnoreCase("fireless")) {
			fireless = true;
		} else if (type.equalsIgnoreCase("backpack")) {
			backpack = true;
		} else if (type.equalsIgnoreCase("ironless")) {
			ironless = true;
		} else if (type.equalsIgnoreCase("limitations")) {
			limitations = true;
		} else if (type.equalsIgnoreCase("splitedlive")) {
			splitedlive = true;
		}
	}
	
	public boolean isEnabled(String type) {
		if (type.equalsIgnoreCase("bowless")) {
			return bowless;
		} else if (type.equalsIgnoreCase("cutclean")) {
			return cutclean;
		} else if (type.equalsIgnoreCase("diamondless")) {
			return diamondless;
		} else if (type.equalsIgnoreCase("horseless")) {
			return horseless;
		} else if (type.equalsIgnoreCase("rodless")) {
			return rodless;
		} else if (type.equalsIgnoreCase("timebomb")) {
			return timebomb;
		} else if (type.equalsIgnoreCase("vanillap")) {
			return vanillap;
		} else if (type.equalsIgnoreCase("fireless")) {
			return fireless;
		} else if (type.equalsIgnoreCase("backpack")) {
			return backpack;
		} else if (type.equalsIgnoreCase("ironless")) {
			return ironless;
		} else if (type.equalsIgnoreCase("limitations")) {
			return limitations;
		} else if (type.equalsIgnoreCase("splitedlive")) {
			return splitedlive;
		}
		return false;
	}
	
}

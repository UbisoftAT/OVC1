package at.ubisoft.odv.gamemanager;

public enum GameState {

	LOBBY, PRE_GAME, INGAME, END;
	
}
